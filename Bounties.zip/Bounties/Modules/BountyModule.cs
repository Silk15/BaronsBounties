﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using ThunderRoad;
using ThunderRoad.Modules;
using TriInspector;
using UnityEngine;
using Object = UnityEngine.Object;

#if !SDK
using IngameDebugConsole;
#endif

namespace BaronsBounties.Bounties.Modules
{
    public class BountyModule : GameModeModule
    {
        [DropdownList(nameof(GetAllBountyID))]
        public List<string> possibleBounties = new();

        #if !SDK
        [NonSerialized]
        public BountySaveData.BountySave bountySaveData;

        [NonSerialized]
        public List<BountyData> possibleBountyData = new();

        public BountyLevelDelegate onLevelBountyAdded;
        public BountyDelegate onBountyAdded;
        public BountyDelegate onBountyRemoved;

        public override IEnumerator OnLoadCoroutine()
        {
            EventManager.onLevelLoad += OnLevelLoad;
            EventManager.onLevelUnload += OnLevelUnload;

            possibleBountyData.Clear();

            foreach (string bounty in possibleBounties)
                possibleBountyData.Add(Catalog.GetData<BountyData>(bounty));
            
            DebugLogConsole.AddCommand("addrandomlevelbounty", "Adds a random bounty to the level board", () => AddBounty(possibleBountyData.OfType<LevelBountyData>().ToList().RandomChoice()));
            DebugLogConsole.AddCommand("addrandombounty", "Adds a random bounty to the player save.", () => AddBounty(possibleBountyData.ToList().RandomChoice()));
            return base.OnLoadCoroutine();
        }

        public override void OnUnload()
        {
            base.OnUnload();
            EventManager.onLevelLoad -= OnLevelLoad;
            EventManager.onLevelUnload -= OnLevelUnload;
        }

        protected virtual void OnLevelLoad(LevelData levelData, LevelData.Mode mode, EventTime eventTime)
        {
            if (eventTime != EventTime.OnEnd) return;
            GameManager.local.StartCoroutine(LoadContentCoroutine(LoadAllBounties));
        }

        protected virtual void OnLevelUnload(LevelData levelData, LevelData.Mode mode, EventTime eventTime)
        {
            if (eventTime != EventTime.OnStart) return;
            BountySaveData.SaveAsync();
        }

        public virtual IEnumerator LoadContentCoroutine(Action onComplete)
        {
            yield return BountySaveData.LoadCoroutine(null);
            if (BountySaveData.instance.TryGetSave(Player.characterData.ID, out bountySaveData)) Debug.Log($"[Baron's Bounties] Loaded: {bountySaveData.activeBounties.Count} active {(bountySaveData.activeBounties.Count == 1 ? "bounty" : "bounties")}{(bountySaveData.activeBounties.Count == 0 ? "." : ":\n - " + string.Join("\n - ", bountySaveData.activeBounties.Select(b => b.referenceID)))}");
            else
            {
                Debug.Log($"[Baron's Bounties] No bounty container found in Player save: {Player.characterData.ID}, adding new.");
                bountySaveData = BountySaveData.instance.AddSave(Player.characterData.ID);
            }

            onComplete?.Invoke();
        }

        public virtual void LoadAllBounties()
        {
            foreach (BountyContent bountyContent in bountySaveData.activeBounties)
                bountyContent.OnCatalogRefresh();
        }

        public virtual void AddContent(BountyContent bountyContent)
        {
            bountySaveData.activeBounties.Add(bountyContent);
            BountySaveData.SaveAsync();
        }

        public virtual void RemoveContent(BountyContent bountyContent)
        {
            if (!bountySaveData.activeBounties.Contains(bountyContent))
                return;

            bountySaveData.activeBounties.Remove(bountyContent);
            BountySaveData.SaveAsync();
        }

        public virtual void AddBounty(BountyData bountyData, BountyContent bountyContent)
        {
        }

        public virtual void RemoveBounty(BountyData bountyData)
        {
        }

        public virtual bool HasBounty(BountyData bountyData) => bountySaveData.activeBounties.Any(b => b.referenceID == bountyData.id);

        public delegate void BountyDelegate(BountyData bountyData);

        public delegate void BountyLevelDelegate(BountyData bountyData, LevelInstance levelInstance);
        #endif

        public TriDropdownList<string> GetAllBountyID() => Catalog.GetDropdownAllID<BountyData>();
    }
}