using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using BaronsBounties.Cargo;
using ThunderRoad;
using UnityEngine;

namespace BaronsBounties.Bounties
{
    [Serializable]
    public class Reward
    {
        public string cargoId;
        public List<ResolvedDrop> resolvedDrops = new();

        [NonSerialized]
        public CargoData cargoData;

        public void OnCatalogRefresh() => cargoData = Catalog.GetData<CargoData>(cargoId);

        public void Spawn(Vector3 position)
        {
            for (int i = 0; i < resolvedDrops.Count; i++)
            {
                resolvedDrops[i].Spawn(cargoData, position, item =>
                {
                    item.SetColliders(false);
                    item.physicBody.isKinematic = true;

                    Item.HolderPoint holderPoint = item.GetHolderPoint("RewardCrateAnchor");
                    Transform anchor = holderPoint != null ? holderPoint.anchor : item.holderPoint;

                    Vector3 anchorOffset = item.transform.position - anchor.position;
                    item.transform.position = position + anchorOffset;

                    item.SetColliders(true);
                    
                    bool clear = false;
                    float shuntStep = 0.1f;
                    Vector3[] directions =
                    {
                        Vector3.up, 
                        Vector3.down, 
                        Vector3.left,
                        Vector3.right, 
                        Vector3.forward, 
                        Vector3.back
                    };

                    for (int attempt = 0; attempt < 16 && !clear; attempt++)
                    {
                        clear = true;
                        foreach (Collider itemCol in item.colliderGroups.SelectMany(g => g.colliders))
                        {
                            foreach (Collider other in Physics.OverlapBox(itemCol.bounds.center, itemCol.bounds.extents, Quaternion.identity, Physics.AllLayers, QueryTriggerInteraction.Ignore))
                            {
                                if (other.transform.IsChildOf(item.transform)) continue;
                                if (Physics.ComputePenetration(itemCol, itemCol.transform.position, itemCol.transform.rotation, other, other.transform.position, other.transform.rotation, out Vector3 dir, out float dist))
                                {
                                    item.transform.position += dir * (dist + 0.01f);
                                    clear = false;
                                    break;
                                }
                            }

                            if (!clear) break;
                        }
                        
                        if (!clear && attempt > 3) item.transform.position = position + anchorOffset + directions[attempt - 4] * shuntStep * (attempt - 3);
                    }

                    if (!clear)
                    {
                        item.transform.position = position + anchorOffset;
                        foreach (Collider itemCol in item.colliderGroups.SelectMany(g => g.colliders))
                        {
                            foreach (Collider other in Physics.OverlapBox(itemCol.bounds.center, itemCol.bounds.extents))
                                if (!other.transform.IsChildOf(item.transform)) Physics.IgnoreCollision(itemCol, other, true);
                        }

                        item.StartCoroutine(ReEnableCollisions(item));
                    }
                    else item.physicBody.isKinematic = false;
                });
            }
        }

        private IEnumerator ReEnableCollisions(Item item)
        {
            float timeout = 60f;
            float elapsed = 0f;

            yield return Yielders.ForSeconds(0.5f);

            while (elapsed < timeout)
            {
                bool overlapping = false;
                foreach (Collider itemCollider in item.colliderGroups.SelectMany(g => g.colliders))
                {
                    if (Physics.OverlapBox(itemCollider.bounds.center, itemCollider.bounds.extents, Quaternion.identity, Physics.AllLayers, QueryTriggerInteraction.Ignore).Any(other => !other.transform.IsChildOf(item.transform)))
                    {
                        overlapping = true;
                        break;
                    }
                }

                if (!overlapping) break;
                elapsed += 0.5f;
                yield return Yielders.ForSeconds(0.5f);
            }

            foreach (Collider itemCollider in item.colliderGroups.SelectMany(g => g.colliders))
                foreach (Collider other in Physics.OverlapBox(itemCollider.bounds.center, itemCollider.bounds.extents))
                    if (!other.transform.IsChildOf(item.transform)) Physics.IgnoreCollision(itemCollider, other, false);

            item.physicBody.isKinematic = false;
        }
    }
}