using System;
using System.Collections.Generic;
using ThunderRoad;
using ThunderRoad.Modules;
using TriInspector;
using UnityEngine;

namespace BaronsBounties.Bounties
{
    public class LevelBountyData : BountyData
    {
        public string mapLocationIconAddress = "Bas.Icon.Location.Arena";
        public string mapLocationIconHoverAddress = "Bas.Icon.Hover.Arena_Highlight";

        public string levelDescription;
        public string levelDisplayName;
        
        [Dropdown(nameof(GetAllLevelID))]
        public string bountyLevelId;
        
        [Dropdown(nameof(GetAllItemID))]
        public string bountyItemId;
        
        public CrystalHuntLevelInstancesModule.LootType lootType;
        public int randomNearest = 0;
        public Vector2Int minMaxMapLocation;
        public List<OffsetStoragePosition> storagePositions = new();

        #if !SDK
        [NonSerialized]
        public LevelData bountyLevelData;

        [NonSerialized]
        public new ItemData bountyItemData;

        public int MapLocation => UnityEngine.Random.Range(minMaxMapLocation.x, minMaxMapLocation.y + 1);

        public override void OnCatalogRefresh()
        {
            base.OnCatalogRefresh();
            bountyLevelData = Catalog.GetData<LevelData>(bountyLevelId);
            bountyItemData = Catalog.GetData<ItemData>(bountyItemId);
        }

        public string LevelDisplayName => LocalizationManager.Instance.TryGetLocalization("Bounties", levelDisplayName);

        public string LevelDescription => LocalizationManager.Instance.TryGetLocalization("Bounties", levelDescription);
        #endif

        public TriDropdownList<string> GetAllItemID() => Catalog.GetDropdownAllID(Category.Item);
        public TriDropdownList<string> GetAllLevelID() => Catalog.GetDropdownAllID(Category.Level);

        [Serializable]
        public class OffsetStoragePosition
        {
            public string[] gameObjectKeywords;
            public Vector3 positionOffset;
            public Quaternion rotationOffset;
        }
    }
}