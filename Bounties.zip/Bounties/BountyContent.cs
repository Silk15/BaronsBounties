﻿using System;
using System.Collections.Generic;
using ThunderRoad;
using ThunderRoad.Modules;
using TriInspector;

namespace BaronsBounties.Bounties
{
    public class BountyContent : ContainerContent
    {
        public List<Reward> rewards = new();
        public List<string> foundItems = new();
        
        public int boardIndex = 0;
        
        [NonSerialized]
        public BountyData bountyData;

        public BountyContent() { }

        public BountyContent(string id) => referenceID = id;

        public override CatalogData catalogData => bountyData;

        public override ContainerContent Clone() => new BountyContent(referenceID);

        public override TriDropdownList<string> DropdownOptions() => new();

        public override string GetTypeString() => GetType().Name;

        public override bool OnCatalogRefresh()
        {
            bountyData = Catalog.GetData<BountyData>(referenceID);
            return true;
        }
    }
}