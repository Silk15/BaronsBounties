using System.Linq;
using ThunderRoad;

#if !SDK
using TMPro;
#endif

namespace BaronsBounties.Bounties
{
    public class UIBountyInfo : ThunderBehaviour
    {
        #if !SDK
        public UICustomisableButton acceptButton;
        public TextMeshPro title;
        public TextMeshPro info;
        public TextMeshPro list;
        
        public void Init(LevelModuleBountyBoard levelModuleBountyBoard, BountyBoard bountyBoard)
        {
            acceptButton = GetComponentInChildren<UICustomisableButton>();
            TextMeshPro[] texts = GetComponentsInChildren<TextMeshPro>();
            title = texts[0];
            info = texts[1];
            list = texts[2];
        }

        public void SetBounty(BountyContent bountyContent)
        {
            title.text = bountyContent.bountyData.BountyDisplayName;
            info.text = bountyContent.bountyData.BountyDescription;
            list.text = "\n- " + string.Join("\n- ", bountyContent.bountyData.bountyItemIds.Select(b => bountyContent.foundItems.Contains(b.itemId) ? $"<s>{b.bountyDetailDescription}</s>" : b.bountyDetailDescription));
        }

        public void ClearBounty()
        {
            title.text = "";
            info.text = "";
            list.text = "";
        }
        #endif
    }
}