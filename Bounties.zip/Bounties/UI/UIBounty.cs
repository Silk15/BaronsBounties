﻿using System;
using System.Linq;
using ThunderRoad;
using UnityEngine.Serialization;

#if !SDK
using TMPro;
using UnityEngine;
#endif

namespace BaronsBounties.Bounties
{
    public class UIBounty : ThunderBehaviour
    {
        #if !SDK
        public UICustomisableButton infoButton;
        public TextMeshPro description;
        public TextMeshPro title;

        [NonSerialized]
        public BountyData bountyData;
        
        public void Init(BountyData bountyData)
        {
            this.bountyData = bountyData;
            infoButton = GetComponentInChildren<UICustomisableButton>();
            TextMeshPro[] texts = GetComponentsInChildren<TextMeshPro>();

            description = texts[0];
            title = texts[1];
        }

        public void Refresh(BountyContent bountyContent)
        {
            description.text = "\n- " + string.Join("\n- ", bountyData.bountyItemIds.Select(i => i.bountyDetailTitle));
            description.text += "\n\n\n Rewards:\n- " + string.Join("\n- ", bountyContent.rewards.Select(r => r.resolvedDrops.Select(r => r.referenceId)));
            title.text = bountyData.BountyDisplayName;
        }
        #endif
    }
}