﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using BaronsBounties.Bounties.Modules;
using ThunderRoad;
using ThunderRoad.Modules;
using UnityEngine;

namespace BaronsBounties.Bounties
{
    public class UIBountyBoard : ThunderBehaviour
    {
        #if !SDK
        public const string UIBountyPrefabAddress = "Silk.UI.Bounty";
        public static GameObject uiBountyPrefab;

        public LevelModuleBountyBoard levelModuleBountyBoard;
        public BountyBoard bountyBoard;

        public List<UIBounty> bounties = new();
        public List<BountyData> bountyData;
        public BountyData selectedBounty;
        public UIBountyInfo bountyInfo;

        public Transform[] bountyPoints;
        
        public void Init(LevelModuleBountyBoard levelModuleBountyBoard, BountyBoard bountyBoard)
        {
            this.levelModuleBountyBoard = levelModuleBountyBoard;
            this.bountyBoard = bountyBoard;
            bountyInfo = bountyBoard.bountyInfo;

            Transform parent = transform.GetChild(0);
            bountyPoints = new Transform[parent.childCount];
            for (int i = 0; i < parent.childCount; i++) bountyPoints[i] = parent.GetChild(i);
    
            bountyData = Catalog.GetDataList<BountyData>();
    
            Catalog.LoadAssetAsync<GameObject>(UIBountyPrefabAddress, prefab =>
            {
                uiBountyPrefab = prefab;
                BountySaveData.LoadAsync(() =>
                {
                    if (ShouldRefresh()) Refresh();
                    else Load();
                    bountyInfo.acceptButton.onPointerClick.AddListener(() => RemoveBounty(selectedBounty));
                });
            }, "UI Bounty Prefab");
        }

        public void Load()
        {
            BountySaveData.BountySave bountySave = BountySaveData.instance.GetSave(Player.characterData.ID);
            if (bountySave.availableBounties.Count == 0)
            {
                Refresh();
                BountySaveData.SaveAsync();
                return;
            }
            foreach (BountyContent bountyContent in bountySave.availableBounties) AddBounty(bountyContent);
            
        }

        private bool ShouldRefresh()
        {
            BountySaveData.BountySave bountySave = BountySaveData.instance.GetSave(Player.characterData.ID);
            if (GameModeManager.instance.currentGameMode.TryGetGameModeSaveData(out CrystalHuntSaveData crystalHuntSaveData))
            {
                if (bountySave.lastRefreshDay == 0 || crystalHuntSaveData.days - bountySave.lastRefreshDay >= levelModuleBountyBoard.refreshDayInterval)
                {
                    bountySave.lastRefreshDay = crystalHuntSaveData.days;
                    BountySaveData.SaveAsync();
                    return true;
                }
                return false;
            }

            Debug.LogError("Cannot load CrystalHuntSaveData");
            return bountySave.availableBounties.Count == 0;
        }
        
        public void Refresh()
        {
            BountySaveData.BountySave bountySave = BountySaveData.instance.GetSave(Player.characterData.ID);
            bountySave.availableBounties.Clear();
            bounties.Clear();
            foreach (UIBounty bounty in GetComponentsInChildren<UIBounty>())
            {
                bountyInfo.ClearBounty();
                Destroy(bounty.gameObject);
            }
            
            int count = levelModuleBountyBoard.minMaxBounties.RandomRangeInt();
            bountyPoints.Shuffle();
            bountyData.Shuffle();

            int limit = Mathf.Min(count, bountyPoints.Length, bountyData.Count);
            for (int i = 0; i < limit; i++) AddBounty(bountyData[i], i);
        }

        public void AddBounty(BountyData bountyData, int index, List<Reward> rewards = null)
        {
            Transform bountyPoint = bountyPoints[index];

            UIBounty uiBounty = Instantiate(uiBountyPrefab, bountyPoint).AddComponent<UIBounty>();
            uiBounty.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
            uiBounty.Init(bountyData);
            bounties.Add(uiBounty);
                
            BountySaveData.BountySave bountySave = BountySaveData.instance.GetSave(Player.characterData.ID);
            BountyContent content = bountySave?.availableBounties?.FirstOrDefault(b => b.referenceID == bountyData.id);
            if (content != null) uiBounty.Refresh(content);
            else
            {
                content = Activator.CreateInstance(bountyData.GetBountyContentType()) as BountyContent;
                content.rewards = rewards ?? bountyData.cargoCollectionData.GetReward();
                content.referenceID = bountyData.id;
                content.boardIndex = index;
                bountySave.availableBounties.Add(content);
                uiBounty.Refresh(content);
                BountySaveData.SaveAsync();
            }

            content.OnCatalogRefresh();
            uiBounty.infoButton.onPointerClick.AddListener(() =>
            {
                selectedBounty = bountyData;
                bountyInfo.SetBounty(content);
            });
        }

        public void AddBounty(BountyContent bountyContent)
        {
            bountyContent.OnCatalogRefresh();
            AddBounty(bountyContent.bountyData, bountyContent.boardIndex, bountyContent.rewards);
        }

        public void RemoveBounty(BountyData bountyData)
        {
            if (bountyData == null) return;
            foreach (UIBounty uiBounty in bounties)
                if (uiBounty.bountyData.id == bountyData.id)
                {
                    BountySaveData.BountySave bountySave = BountySaveData.instance.GetSave(Player.characterData.ID);
                    BountyContent bountyContent = bountySave.GetAvailableBounty(bountyData.id);
                    if (bountyContent != null)
                    {
                        bountySave.availableBounties.Remove(bountyContent);
                        if (GameModeManager.instance.currentGameMode.TryGetModule(out BountyModule bountyModule))
                        {
                            bountyModule.AddBounty(bountyData);
                        }
                        else Debug.LogError("No Bounty Module found in the current game mode! Selecting bounties is pointless.");
                    }
                    Destroy(uiBounty.gameObject);
                    bountyInfo.ClearBounty();
                }
            BountySaveData.SaveAsync();
        }
        #endif
    }
}