using System;
using System.Collections;
using BaronsBounties.Bounties.Modules;
using System.Linq;
using ThunderRoad;
using ThunderRoad.Modules;

namespace BaronsBounties.Bounties.Sandbox.Modules
{
    public class SandboxBountyModule : BountyModule
    {
        public SandboxLevelInstancesModule sandboxLevelInstancesModule;
        public override IEnumerator LoadContentCoroutine(Action onComplete)
        {
            GameModeManager.Instance.currentGameMode.TryGetModule(out sandboxLevelInstancesModule);
            return base.LoadContentCoroutine(onComplete);
        }

        public override void LoadAllBounties()
        {
            base.LoadAllBounties();
            foreach (SandboxBountyContent sandboxBountyContent in bountySaveData.activeBounties.OfType<SandboxBountyContent>())
            {
                switch (sandboxBountyContent)
                {
                    case SandboxLevelBountyContent sandboxLevelBountyContent:
                        AddLevelBounty(sandboxLevelBountyContent);
                        break;
                }
            }
        }

        public void AddLevelBounty(SandboxLevelBountyContent sandboxLevelBountyContent)
        {
            
        }
        
        public override void AddBounty(BountyData bountyData)
        {
            base.AddBounty(bountyData);
            switch (bountyData)
            {
                case LevelBountyData levelBountyData:
                    AddLevelBounty(levelBountyData);
                    break;
                
                default:
                    AddContent();
            }
        }

        public override void AddContent(BountyContent bountyContent)
        {
            base.AddContent(bountyContent);
        }
        
        public IEnumerator GetLevelData(LevelBountyData levelBountyData, Action<LevelData> onComplete = null)
        {
            LevelData levelData = levelBountyData.bountyLevelData.CloneJson();
            levelData.id += levelBountyData.id;
            levelData.name = $"{levelBountyData.LevelDisplayName} ({levelBountyData.bountyItemData.displayName})";

            levelData.mapLocationIconAddress = levelBountyData.mapLocationIconAddress;
            levelData.mapLocationIconHoverAddress = levelBountyData.mapLocationIconHoverAddress;

            yield return levelData.OnCatalogRefreshCoroutine();
            onComplete?.Invoke(levelData);
        }
        
        private string GetEnemyConfig() => Catalog.GetDataList(Category.EnemyConfig).RandomChoice().id;
       

        private string GetLootConfig() => Catalog.GetDataList(Category.LootConfig).RandomChoice().id;
    }
}