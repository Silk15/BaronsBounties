namespace BaronsBounties.Bounties.Sandbox
{
    public class SandboxLevelBountyContent : SandboxBountyContent
    {
        public int dungeonLength;
        public int randomNearest;
        public int mapIndex;
        public string enemyConfigDataId;
        public string lootConfigDataId;
        public string levelId;
    }
}