namespace BaronsBounties.Bounties.Sandbox
{
    public class SandboxBountyContent : BountyContent
    {
        public SandboxBountyContent()
        {
            
        }
        
        public SandboxBountyContent(string bountyId) => this.referenceID = bountyId;
    }
}