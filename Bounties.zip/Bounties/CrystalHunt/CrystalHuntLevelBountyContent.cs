﻿using System;
using ThunderRoad;

namespace BaronsBounties.Bounties.CrystalHunt
{
    public class CrystalHuntLevelBountyContent : CrystalHuntBountyContent
    {
        #if !SDK
        public CrystalHuntDungeonEndRewardBalance.EndRewardLootMultiplier endRewardLootMultiplier;
        public CrystalHuntLevelInstanceData.CrystalHuntLevelType levelType;
        public float tierLengthLootMultiplier;
        public int dungeonLength;
        public int factionTier;
        public int randomNearest;
        public int mapIndex;
        public string enemyConfigDataId;
        public string lootConfigDataId;
        public string levelId;

        [NonSerialized]
        public EnemyConfig enemyConfigData;

        [NonSerialized]
        public LootConfigData lootConfigData;

        [NonSerialized]
        public LevelData levelData;

        [NonSerialized]
        public LevelBountyData levelBountyData;

        [NonSerialized]
        public LevelInstance levelInstance;

        public CrystalHuntLevelBountyContent()
        {
        }

        public CrystalHuntLevelBountyContent(CrystalHuntLevelInstanceData crystalHuntLevelInstanceData, BountyData bountyData, LevelData levelData, int factionTier, int dungeonLength)
        {
            tierLengthLootMultiplier = crystalHuntLevelInstanceData.tierLengthLootMultiplier;
            endRewardLootMultiplier = crystalHuntLevelInstanceData.endRewardLootMultiplier;
            levelType = crystalHuntLevelInstanceData.levelType;

            this.factionTier = factionTier;
            this.dungeonLength = dungeonLength;

            enemyConfigDataId = crystalHuntLevelInstanceData.enemyConfigDataId;
            lootConfigDataId = crystalHuntLevelInstanceData.lootConfigDataId;

            mapIndex = crystalHuntLevelInstanceData.mapLocationIndex;
            randomNearest = crystalHuntLevelInstanceData.randomNearest;

            referenceID = bountyData.id;
            levelId = levelData.id;
        }

        public override bool OnCatalogRefresh()
        {
            enemyConfigData = Catalog.GetData<EnemyConfig>(enemyConfigDataId);
            lootConfigData = Catalog.GetData<LootConfigData>(lootConfigDataId);
            levelBountyData = Catalog.GetData<LevelBountyData>(referenceID);
            levelData = Catalog.GetData<LevelData>(levelId);
            return base.OnCatalogRefresh();
        }
        #endif
    }
}