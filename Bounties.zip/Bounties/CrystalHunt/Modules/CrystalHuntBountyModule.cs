﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using BaronsBounties.Bounties.Modules;
using ThunderRoad;
using ThunderRoad.Modules;
using UnityEngine;
using Object = UnityEngine.Object;

namespace BaronsBounties.Bounties.CrystalHunt.Modules
{
    public class CrystalHuntBountyModule : BountyModule
    {
        #if !SDK

        [NonSerialized]
        public CrystalHuntSaveData saveData;

        [NonSerialized]
        public CrystalHuntLevelInstancesModule crystalHuntLevelInstancesModule;

        [NonSerialized]
        public CrystalHuntDungeonLengthBalance dungeonLengthBalance;

        [NonSerialized]
        private CrystalHuntDungeonEndRewardBalance endRewardLootMultipliers;

        [NonSerialized]
        private CrystalHuntFactionTierBalance outpostFactionTierBalance;

        public override IEnumerator OnLoadCoroutine()
        {
            yield return base.OnLoadCoroutine();
            GameModeManager.Instance.currentGameMode.TryGetModule(out crystalHuntLevelInstancesModule);
            saveData = GameModeManager.Instance.currentGameMode.GetGameModeSaveData() as CrystalHuntSaveData;

            if (!string.IsNullOrEmpty(crystalHuntLevelInstancesModule.dungeonLengthBalanceAddress))
                yield return Catalog.LoadAssetCoroutine<CrystalHuntDungeonLengthBalance>(crystalHuntLevelInstancesModule.dungeonLengthBalanceAddress, balance => dungeonLengthBalance = balance, "Crystal Hunt Bounty Module");

            if (!string.IsNullOrEmpty(crystalHuntLevelInstancesModule.endRewardBalanceAddress))
                yield return Catalog.LoadAssetCoroutine<CrystalHuntDungeonEndRewardBalance>(crystalHuntLevelInstancesModule.endRewardBalanceAddress, balance => endRewardLootMultipliers = balance, "Crystal Hunt Bounty Module");

            if (!string.IsNullOrEmpty(crystalHuntLevelInstancesModule.outpostFactionTierBalanceAddress))
                yield return Catalog.LoadAssetCoroutine<CrystalHuntFactionTierBalance>(crystalHuntLevelInstancesModule.outpostFactionTierBalanceAddress, balance => outpostFactionTierBalance = balance, "Crystal Hunt Bounty Module");
        }

        public override void LoadAllBounties()
        {
            base.LoadAllBounties();
            foreach (CrystalHuntBountyContent crystalHuntBountyContent in bountySaveData.activeBounties.OfType<CrystalHuntBountyContent>())
            {
                switch (crystalHuntBountyContent)
                {
                    case CrystalHuntLevelBountyContent crystalHuntLevelBountyContent:
                        AddLevelBounty(crystalHuntLevelBountyContent, null);
                        break;
                }
            }
        }

        public override void AddBounty(BountyData bountyData, BountyContent bountyContent)
        {
            base.AddBounty(bountyData, bountyContent);
            if (crystalHuntLevelInstancesModule != null)
                switch (bountyData)
                {
                    case LevelBountyData levelBountyData:
                        int factionTier = outpostFactionTierBalance.GetFactionTier(saveData.levelProgression + 2);
                        int dungeonLength = dungeonLengthBalance.GetDungeonLength(saveData.levelProgression);

                        CrystalHuntDungeonLootMultiplierBalance tierLengthLootMultipliers = crystalHuntLevelInstancesModule.GetField("tierLengthLootMultipliers") as CrystalHuntDungeonLootMultiplierBalance;
                        CrystalHuntDungeonEndRewardBalance.EndRewardLootMultiplier endRewardLootMultiplier = endRewardLootMultipliers.GetEndRewardLootMultiplier(levelBountyData.lootType);
                        LevelData.Mode mode = crystalHuntLevelInstancesModule.outpostDungeonLevelInfo.GetMode();

                        float multiplierChance = tierLengthLootMultipliers.GetLootMultiplierChance(factionTier, dungeonLength);

                        List<(string, Color)> rewardTierIcons = tierLengthLootMultipliers.GetRewardTierIcons(levelBountyData.lootType, factionTier, dungeonLength);
                        CrystalHuntLevelInstanceData levelInstanceData = new(dungeonLength, GetLootConfig(crystalHuntLevelInstancesModule.outpostLootConfigs, factionTier), GetEnemyConfig(crystalHuntLevelInstancesModule.outpostEnemyConfigs, factionTier), rewardTierIcons, crystalHuntLevelInstancesModule.difficultyIcon, crystalHuntLevelInstancesModule.difficultyIconColor);
                        levelInstanceData.mapLocationIndex = levelBountyData.MapLocation;
                        levelInstanceData.randomNearest = levelBountyData.randomNearest;
                        levelInstanceData.tierLengthLootMultiplier = multiplierChance;
                        levelInstanceData.endRewardLootMultiplier = endRewardLootMultiplier;
                        levelInstanceData.lootType = levelBountyData.lootType;
                        levelInstanceData.levelType = CrystalHuntLevelInstanceData.CrystalHuntLevelType.Dungeon;

                        GameManager.local.StartCoroutine(GetLevelData(levelBountyData, levelData =>
                        {
                            LevelInstance levelInstance = new(levelData, mode, levelInstanceData);
                            CrystalHuntLevelBountyContent levelBountyContent = new(levelInstanceData, levelBountyData, crystalHuntLevelInstancesModule.outpostDungeonLevelInfo.LevelData, factionTier, dungeonLength);
                            AddContent(levelBountyContent);
                            levelBountyContent.levelInstance = levelInstance;
                            AddToLevelInstances(levelInstance);

                            onLevelBountyAdded?.Invoke(levelBountyData, levelInstance);
                            onBountyAdded?.Invoke(levelBountyData);
                        }));
                        break;

                    default:
                        CrystalHuntBountyContent crystalHuntBountyContent = new(bountyData.id)
                        {
                            bountyData = bountyData,
                            boardIndex = 0
                        };
                        AddContent(crystalHuntBountyContent);
                        onBountyAdded?.Invoke(bountyData);
                        break;
                }
        }

        public void AddLevelBounty(CrystalHuntLevelBountyContent crystalHuntLevelBountyContent, Action<LevelInstance> onComplete)
        {
            if (crystalHuntLevelInstancesModule != null)
            {
                int factionTier = crystalHuntLevelBountyContent.factionTier;
                int dungeonLength = crystalHuntLevelBountyContent.dungeonLength;

                CrystalHuntDungeonLootMultiplierBalance tierLengthLootMultipliers = crystalHuntLevelInstancesModule.GetField("tierLengthLootMultipliers") as CrystalHuntDungeonLootMultiplierBalance;
                CrystalHuntDungeonEndRewardBalance.EndRewardLootMultiplier endRewardLootMultiplier = crystalHuntLevelBountyContent.endRewardLootMultiplier;
                LevelData.Mode mode = crystalHuntLevelInstancesModule.outpostDungeonLevelInfo.GetMode();

                float multiplierChance = crystalHuntLevelBountyContent.tierLengthLootMultiplier;

                List<(string, Color)> rewardTierIcons = tierLengthLootMultipliers.GetRewardTierIcons(crystalHuntLevelBountyContent.levelBountyData.lootType, factionTier, dungeonLength);
                CrystalHuntLevelInstanceData levelInstanceData = new CrystalHuntLevelInstanceData(dungeonLength, GetLootConfig(crystalHuntLevelInstancesModule.outpostLootConfigs, factionTier), GetEnemyConfig(crystalHuntLevelInstancesModule.outpostEnemyConfigs, factionTier), rewardTierIcons, crystalHuntLevelInstancesModule.difficultyIcon, crystalHuntLevelInstancesModule.difficultyIconColor);
                levelInstanceData.mapLocationIndex = crystalHuntLevelBountyContent.mapIndex;
                levelInstanceData.randomNearest = crystalHuntLevelBountyContent.randomNearest;
                levelInstanceData.tierLengthLootMultiplier = multiplierChance;
                levelInstanceData.endRewardLootMultiplier = endRewardLootMultiplier;
                levelInstanceData.lootType = crystalHuntLevelBountyContent.levelBountyData.lootType;
                levelInstanceData.levelType = CrystalHuntLevelInstanceData.CrystalHuntLevelType.Dungeon;

                GameManager.local.StartCoroutine(GetLevelData(crystalHuntLevelBountyContent.levelBountyData, levelData =>
                {
                    LevelInstance levelInstance = new LevelInstance(levelData, mode, levelInstanceData);
                    crystalHuntLevelBountyContent.levelInstance = levelInstance;
                    onComplete?.Invoke(levelInstance);
                    AddToLevelInstances(levelInstance);
                }));
            }
        }

        public override void RemoveBounty(BountyData bountyData)
        {
            base.RemoveBounty(bountyData);
            foreach (BountyContent bountyContent in bountySaveData.activeBounties)
                if (bountyContent.referenceID == bountyData.id)
                {
                    RemoveContent(bountyContent);
                    if (bountyContent is CrystalHuntLevelBountyContent crystalHuntLevelBountyContent && crystalHuntLevelBountyContent.levelInstance != null)
                        RemoveFromLevelInstances(crystalHuntLevelBountyContent.levelInstance);
                }

            onBountyRemoved?.Invoke(bountyData);
        }

        public void AddToLevelInstances(LevelInstance levelInstance)
        {
            List<LevelInstance> levelInstances = crystalHuntLevelInstancesModule.GetField("outpostLevelInstances") as List<LevelInstance>;
            levelInstances.Add(levelInstance);
            crystalHuntLevelInstancesModule.BuildLevelInstances();
        }

        public void RemoveFromLevelInstances(LevelInstance levelInstance)
        {
            List<LevelInstance> levelInstances = crystalHuntLevelInstancesModule.GetField("outpostLevelInstances") as List<LevelInstance>;
            if (!levelInstances.Contains(levelInstance)) return;

            levelInstances.Remove(levelInstance);
            crystalHuntLevelInstancesModule.BuildLevelInstances();
        }

        public IEnumerator GetLevelData(LevelBountyData levelBountyData, Action<LevelData> onComplete = null)
        {
            LevelData levelData = levelBountyData.bountyLevelData.CloneJson();
            levelData.id += levelBountyData.id;
            levelData.name = $"{levelBountyData.LevelDisplayName} ({levelBountyData.bountyItemData.displayName})";

            levelData.mapLocationIconAddress = levelBountyData.mapLocationIconAddress;
            levelData.mapLocationIconHoverAddress = levelBountyData.mapLocationIconHoverAddress;

            yield return levelData.OnCatalogRefreshCoroutine();
            onComplete?.Invoke(levelData);
        }

        private string GetEnemyConfig(CrystalHuntLevelInstancesModule.EnemyConfigTiers configTiers, int factionTier)
        {
            List<string> tier = configTiers.GetTier(factionTier);
            if (!tier.IsNullOrEmpty()) return tier[UnityEngine.Random.Range(0, tier.Count)];
            return null;
        }

        private string GetLootConfig(CrystalHuntLevelInstancesModule.LootConfigTiers configTiers, int factionTier)
        {
            List<string> tier = configTiers.GetTier(factionTier);
            if (!tier.IsNullOrEmpty()) return tier[UnityEngine.Random.Range(0, tier.Count)];
            return null;
        }
        #endif
    }
}