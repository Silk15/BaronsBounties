using System;
using BaronsBounties.Cargo;
using ThunderRoad;
using UnityEngine;

namespace BaronsBounties.Bounties
{
    [Serializable]
    public class ResolvedDrop
    {
        public string referenceId;
        public CargoData.Drop.DropType dropType;
        public int quantity;
        public int amount;

        public void Spawn(CargoData cargoData, Vector3 position, Action<Item> onComplete)
        {
            CargoData.Drop drop = cargoData.GetDrop(referenceId);
            switch (dropType)
            {
                case CargoData.Drop.DropType.Item:
                    for (int i = 0; i < quantity; i++) drop.itemData.SpawnAsync(onComplete, position, Quaternion.identity);
                    break;
                
                case CargoData.Drop.DropType.Currency:
                    drop.itemData.SpawnAsync(item =>
                    {
                        item.SetValue(amount);
                        onComplete?.Invoke(item);
                    }, position, Quaternion.identity);
                    break;
                
                case CargoData.Drop.DropType.Table:
                    foreach (ItemData itemData in drop.lootTable.Pick()) itemData.SpawnAsync(onComplete, position, Quaternion.identity);
                    break;
            }
        }
    }
}