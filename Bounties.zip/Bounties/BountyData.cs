﻿using System;
using System.Linq;
using BaronsBounties.Bounties.CrystalHunt;
using BaronsBounties.Cargo;
using Newtonsoft.Json;
using ThunderRoad;
using TriInspector;
using UnityEngine;

namespace BaronsBounties.Bounties
{
    [Serializable, DeclareHorizontalGroup("Horizontal"), DeclareHorizontalGroup("HorizontalToggles")]
    public class BountyData : CustomData
    {
        [Group("Horizontal"), TextArea(5, 15)]
        public string bountyDisplayName;
        
        [Group("Horizontal"), TextArea(5, 15)]
        public string bountyDescription;
        
        public bool isBountyUnique;
        public bool showOnBoard = true;
        
        public BountyItem[] bountyItemIds;

        [Dropdown(nameof(GetAllCargoCollectionID))]
        public string cargoCollectionId;

        [NonSerialized]
        public CargoCollectionData cargoCollectionData;

        [NonSerialized]
        public ItemData[] bountyItemData;
        
        #if !SDK
        [JsonIgnore]
        public string BountyDisplayName => LocalizationManager.Instance.TryGetLocalization("Bounties", bountyDisplayName);

        [JsonIgnore]
        public string BountyDescription => LocalizationManager.Instance.TryGetLocalization("Bounties", bountyDescription);

        public virtual Type GetBountyContentType()
        {
            switch (GameModeManager.instance.currentGameMode.id)
            {
                case "CrystalHunt":
                    if (this is LevelBountyData) return typeof(CrystalHuntLevelBountyContent);
                    return typeof(CrystalHuntBountyContent);
                
                case "Sandbox":
                    return typeof(BountyContent);
            }
            return typeof(BountyContent);
        }
        
        public override void OnCatalogRefresh()
        {
            base.OnCatalogRefresh();
            bountyItemData = bountyItemIds.Select(b => b.itemId).AsDataArray<ItemData>();
            cargoCollectionData = Catalog.GetData<CargoCollectionData>(cargoCollectionId);
        }
        #endif
        
        #if UNITY_EDITOR
        public override string GetCatalogPath()
        {
            string result = $"Bounties";
            if (!groupPath.IsNullOrEmptyOrWhitespace()) result += $"/{groupPath}";
            if (result[result.Length - 1] == '/') result = result.Substring(0, result.Length - 1);
            return result;
        }
        #endif
        
        public TriDropdownList<string> GetAllCargoCollectionID() => Catalog.GetDropdownAllID<CargoCollectionData>();

        [Serializable, DeclareHorizontalGroup("Horizontal")]
        public class BountyItem
        {
            [Dropdown(nameof(GetAllItemID)), HideLabel]
            public string itemId;
            
            [Group("Horizontal"), TextArea(2, 5)]
            public string bountyDetailDescription;
            
            [Group("Horizontal"), TextArea(2, 5)]
            public string bountyDetailTitle;
            
            public TriDropdownList<string> GetAllItemID() => Catalog.GetDropdownAllID(Category.Item);
        }
    }
}